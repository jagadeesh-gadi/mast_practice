#!/usr/bin/env bash

set -Eeuo pipefail

PROJECT_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
export PROJECT_ROOT
export UPDATE_LOG_TAG="health-test"
export DISK_WARNING_THRESHOLD=80

source "$PROJECT_ROOT/lib/logging.sh"
source "$PROJECT_ROOT/lib/health-monitor.sh"
source "$PROJECT_ROOT/lib/report-generator.sh"

temp_dir="$(mktemp -d)"
trap 'rm -rf "$temp_dir"' EXIT

mock_dir="$temp_dir/mock-bin"
mkdir -p "$mock_dir"

export MOCK_DISK_MODE="normal"
export MOCK_SERVICE_MODE="healthy"

# Mock df to simulate normal and high disk usage.
cat > "$mock_dir/df" <<'MOCK'
#!/usr/bin/env bash

if [[ "${MOCK_DISK_MODE:-normal}" == "high" ]]; then
    printf 'Filesystem 1024-blocks Used Available Capacity Mounted on\n'
    printf '/dev/mock 1000 850 150 85%% /\n'
else
    printf 'Filesystem 1024-blocks Used Available Capacity Mounted on\n'
    printf '/dev/mock 1000 500 500 50%% /\n'
fi
MOCK

# Mock systemctl without changing real system services.
cat > "$mock_dir/systemctl" <<'MOCK'
#!/usr/bin/env bash

case "${MOCK_SERVICE_MODE:-healthy}" in
    healthy)
        exit 0
        ;;
    failed)
        echo "test.service loaded failed failed Test service"
        exit 0
        ;;
    error)
        echo "Simulated systemctl error" >&2
        exit 1
        ;;
esac
MOCK

chmod +x "$mock_dir/df" "$mock_dir/systemctl"
export PATH="$mock_dir:$PATH"

passed=0
failed=0

check_result() {
    local description="$1"
    local expected="$2"
    shift 2

    local actual=0

    if "$@" >"$temp_dir/output" 2>&1; then
        actual=0
    else
        actual=$?
    fi

    if [[ "$actual" -eq "$expected" ]]; then
        echo "[PASS] $description"
        passed=$((passed + 1))
    else
        echo "[FAIL] $description (expected $expected, got $actual)"
        cat "$temp_dir/output"
        failed=$((failed + 1))
    fi
}

check_result "Disk usage below threshold" 0 check_disk_usage 80

export MOCK_DISK_MODE="high"
check_result "High disk usage produces warning status" 1 check_disk_usage 80

export MOCK_SERVICE_MODE="healthy"
check_result "No failed services detected" 0 check_failed_services

export MOCK_SERVICE_MODE="failed"
check_result "Failed service detected" 1 check_failed_services

export MOCK_SERVICE_MODE="error"
check_result "Systemd query failure detected" 2 check_failed_services

# Restore real system commands for report generation.
export PATH="${PATH#"$mock_dir:"}"

if generate_health_report "$temp_dir" >"$temp_dir/report-output" 2>&1; then
    report="$(find "$temp_dir" -maxdepth 1 -name 'health-report-*.txt' -print -quit)"

    if [[ -n "$report" ]] && grep -q "Health Report" "$report"; then
        echo "[PASS] Health report generated"
        passed=$((passed + 1))
    else
        echo "[FAIL] Health report missing or incomplete"
        failed=$((failed + 1))
    fi
else
    echo "[FAIL] Health report generation"
    cat "$temp_dir/report-output"
    failed=$((failed + 1))
fi

echo
echo "Passed: $passed"
echo "Failed: $failed"

[[ "$failed" -eq 0 ]]
