#!/usr/bin/env bash

set -Eeuo pipefail

PROJECT_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$PROJECT_ROOT"

passed=0
failed=0

pass() {
    echo "[PASS] $1"
    passed=$((passed + 1))
}

fail() {
    echo "[FAIL] $1"
    failed=$((failed + 1))
}

echo "Running update application tests..."
echo

# Test Bash syntax without executing update commands.
for file in bin/auto-update.sh lib/*.sh; do
    if bash -n "$file"; then
        pass "Bash syntax: $file"
    else
        fail "Bash syntax: $file"
    fi
done

# Test help output.
if output="$(./bin/auto-update.sh --help 2>&1)" &&
   grep -q "Usage:" <<< "$output"; then
    pass "Help option"
else
    fail "Help option"
fi

# Test invalid option handling.
if ./bin/auto-update.sh --invalid-option >/dev/null 2>&1; then
    fail "Invalid option was accepted"
else
    status=$?
    if [[ "$status" -eq 2 ]]; then
        pass "Invalid option rejected with exit code 2"
    else
        fail "Invalid option returned unexpected exit code: $status"
    fi
fi

echo
echo "Passed: $passed"
echo "Failed: $failed"

if [[ "$failed" -gt 0 ]]; then
    exit 1
fi
