#!/usr/bin/env bash

set -Eeuo pipefail

PROJECT_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
export UPDATE_LOG_TAG="repository-test"

source "$PROJECT_ROOT/lib/logging.sh"
source "$PROJECT_ROOT/lib/update-manager.sh"

temp_dir="$(mktemp -d)"
trap 'rm -rf "$temp_dir"' EXIT

export MOCK_APT_MODE="success"

cat > "$temp_dir/mock-apt-get" <<'MOCK'
#!/usr/bin/env bash

if [[ "${1:-}" != "update" ]]; then
    echo "Unexpected mock APT command: $*" >&2
    exit 2
fi

case "$MOCK_APT_MODE" in
    success)
        echo "Reading package lists... Done"
        exit 0
        ;;
    warning)
        echo "W: Some repository indexes could not be downloaded."
        exit 0
        ;;
    failure)
        echo "E: Failed to fetch repository metadata."
        exit 100
        ;;
    *)
        echo "Unknown mock mode" >&2
        exit 2
        ;;
esac
MOCK

chmod +x "$temp_dir/mock-apt-get"
APT_GET="$temp_dir/mock-apt-get"

passed=0
failed=0

check_result() {
    local description="$1"
    local expected="$2"
    local actual=0

    if refresh_package_lists > "$temp_dir/output" 2>&1; then
        actual=0
    else
        actual=$?
    fi

    if [[ "$actual" -eq "$expected" ]]; then
        echo "[PASS] $description"
        passed=$((passed + 1))
    else
        echo "[FAIL] $description (expected $expected, got $actual)"
        cat "$temp_dir/output"
        failed=$((failed + 1))
    fi
}

check_result "Clean repository update accepted" 0

export MOCK_APT_MODE="warning"
check_result "Repository warning rejected" 1

export MOCK_APT_MODE="failure"
check_result "APT command failure rejected" 100

echo
echo "Passed: $passed"
echo "Failed: $failed"

[[ "$failed" -eq 0 ]]
