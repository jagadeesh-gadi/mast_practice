#!/usr/bin/env bash

# Automated Linux System Update Service
# Target: Ubuntu/Debian using APT

set -Eeuo pipefail

LOG_TAG="auto-linux-update"
LOCK_FILE="/run/lock/auto-linux-update.lock"

log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') [$LOG_TAG] $*"
}

handle_error() {
    local exit_code=$?
    log "ERROR: Update failed near line ${BASH_LINENO[0]} (exit code: ${exit_code})"
    exit "$exit_code"
}

trap handle_error ERR

# Require administrator privileges
if [[ "$EUID" -ne 0 ]]; then
    log "ERROR: Run this script with sudo or through a root systemd service."
    exit 1
fi

# Prevent overlapping executions of this script
exec 9>"$LOCK_FILE"

if ! flock -n 9; then
    log "Another update job is running. Skipping this run."
    exit 0
fi

# Prevent interactive package configuration prompts
export DEBIAN_FRONTEND=noninteractive

log "Starting automated system update."

log "Refreshing APT package lists..."
apt-get update

log "Installing available package upgrades..."
apt-get -y upgrade

log "System update completed successfully."
