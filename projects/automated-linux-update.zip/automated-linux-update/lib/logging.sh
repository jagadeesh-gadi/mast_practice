#!/usr/bin/env bash

log() {
    local message
    message="$(date '+%Y-%m-%d %H:%M:%S') [$UPDATE_LOG_TAG] $*"

    printf '%s\n' "$message"

    if [[ -n "${LOG_FILE:-}" ]]; then
        mkdir -p "$(dirname "$LOG_FILE")"
        printf '%s\n' "$message" >> "$LOG_FILE"
    fi
}

error() {
    log "ERROR: $*" >&2
}

handle_error() {
    local exit_code=$?
    local line_number="${BASH_LINENO[0]:-unknown}"

    error "Command failed near line ${line_number} (exit code: ${exit_code})."
    exit "$exit_code"
}
