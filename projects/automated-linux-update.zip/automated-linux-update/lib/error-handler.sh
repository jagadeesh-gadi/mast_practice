#!/usr/bin/env bash

handle_update_error() {
    local exit_code="${1:-1}"
    local message="${2:-An unexpected error occurred}"

    error "$message (exit code: $exit_code)"
    return "$exit_code"
}
