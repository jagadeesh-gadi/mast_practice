#!/usr/bin/env bash

check_disk_usage() {
    local threshold="${1:-${DISK_WARNING_THRESHOLD:-80}}"

    log "Checking disk usage (warning threshold: ${threshold}%)."

    df -P -x tmpfs -x devtmpfs |
    awk -v threshold="$threshold" '
        NR > 1 {
            usage = $5
            gsub(/%/, "", usage)

            if (usage + 0 >= threshold) {
                printf "WARNING: %s is %s%% full (mounted on %s)\n",
                       $1, usage, $6
                warning = 1
            }
        }
        END {
            if (warning)
                exit 1
        }
    '
}

check_memory_usage() {
    log "Checking memory usage."
    free -m
}

check_system_uptime() {
    log "Checking system uptime."
    uptime
}

check_failed_services() {
    local failed_services

    log "Checking failed systemd services."

    if ! failed_services="$(systemctl --failed --no-legend --no-pager)"; then
        error "Unable to retrieve failed systemd services."
        return 2
    fi

    if [[ -z "$failed_services" ]]; then
        log "No failed systemd services detected."
        return 0
    fi

    printf '%s\n' "$failed_services"
    log "WARNING: Failed systemd services were detected."
    return 1
}
