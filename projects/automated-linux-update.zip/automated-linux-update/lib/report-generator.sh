#!/usr/bin/env bash

generate_health_report() {
    local report_dir="${1:-${REPORT_DIR:-$PROJECT_ROOT/reports}}"
    local timestamp
    local report_file

    timestamp="$(date '+%Y%m%d-%H%M%S')"
    report_file="$report_dir/health-report-$timestamp.txt"

    mkdir -p "$report_dir"

    {
        echo "Automated Linux System Update Service"
        echo "Health Report"
        echo "Generated: $(date)"
        echo
        echo "===== Hostname ====="
        hostname
        echo
        echo "===== Uptime ====="
        uptime
        echo
        echo "===== Disk Usage ====="
        df -h
        echo
        echo "===== Memory Usage ====="
        free -h
        echo
        echo "===== Failed Services ====="
        systemctl --failed --no-pager || true
    } > "$report_file"

    log "Health report saved to $report_file"
}
