#!/usr/bin/env bash

require_command() {
    local command_name="$1"

    if ! command -v "$command_name" >/dev/null 2>&1; then
        error "Required command not found: $command_name"
        return 1
    fi
}

require_root() {
    if [[ "$EUID" -ne 0 ]]; then
        error "This operation requires root privileges. Use sudo."
        return 1
    fi
}

validate_configuration() {
    if [[ ! -x "$APT_GET" ]]; then
        error "APT executable is missing or not executable: $APT_GET"
        return 1
    fi

    require_command flock
    require_command date

    log "Configuration validation passed."
}
