#!/usr/bin/env bash

acquire_update_lock() {
    require_root || return 1

    exec 9>"$LOCK_FILE"

    if ! flock -n 9; then
        log "Another update job is running. Skipping this run."
        return 2
    fi

    log "Update lock acquired."
}

refresh_package_lists() {
    local output
    local status

    log "Refreshing APT package lists."

    # Capture output while preserving APT's exit status.
    if output="$("$APT_GET" update 2>&1)"; then
        status=0
    else
        status=$?
    fi

    printf '%s\n' "$output"

    if [[ "$status" -ne 0 ]]; then
        error "APT update failed with exit code $status."
        return "$status"
    fi

    # Strict mode: do not continue if APT reports warnings or errors.
    if grep -Eq '^(W:|Err:)' <<< "$output"; then
        error "APT reported repository warnings or errors."
        error "Review the output and fix the repository before continuing."
        return 1
    fi

    log "APT package lists refreshed without reported warnings."
}

check_updates() {
    log "Checking upgrades using existing APT package lists."
    log "Simulation mode: no packages will be installed."

    "$APT_GET" -s upgrade
}

dry_run_update() {
    local lock_status=0

    if acquire_update_lock; then
        :
    else
        lock_status=$?
        if [[ "$lock_status" -eq 2 ]]; then
            return 0
        fi
        return "$lock_status"
    fi

    export DEBIAN_FRONTEND=noninteractive

    refresh_package_lists

    log "Simulating available package upgrades."
    "$APT_GET" -s upgrade

    log "Dry-run completed. No package upgrades were installed."
}

run_update() {
    local lock_status=0

    if acquire_update_lock; then
        :
    else
        lock_status=$?
        if [[ "$lock_status" -eq 2 ]]; then
            return 0
        fi
        return "$lock_status"
    fi

    export DEBIAN_FRONTEND=noninteractive

    log "Starting automated system update."

    # Stop before installing upgrades if repository validation fails.
    refresh_package_lists

    log "Installing available package upgrades."
    "$APT_GET" -y upgrade

    log "System update completed successfully."
}
