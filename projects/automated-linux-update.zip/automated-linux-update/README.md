# Automated Linux System Update Service

## 1. Project Overview

The Automated Linux System Update Service is a Bash-based Linux administration project that automates package updates on Ubuntu using APT and systemd.

The project is being extended with system health monitoring, error handling, report generation, and automated tests.

Project overview and objectives
Features: automated APT updates, health monitoring, logging, reports, and dashboard
Technologies used: Bash, APT, systemd, Python, Flask, and logrotate
Project directory structure
Installation and configuration
Commands for health checks, reports, dry-runs, and updates
Test commands and results
Dashboard startup instructions
Log rotation configuration
Backup and rollback procedure


## 2. Objectives

- Automate package list updates and package upgrades.
- Schedule updates using systemd timers.
- Prevent overlapping update jobs using file locking.
- Record application activity and errors.
- Monitor disk usage, memory, uptime, and failed systemd services.
- Generate system health reports.
- Test application behavior before deployment.

## 3. Technologies

- Operating System: Ubuntu Linux
- Scripting: Bash
- Package Manager: APT
- Service Management: systemd
- Logging: systemd journal
- Testing: Bash scripts
- Planned Extension: Python and Flask dashboard

## 4. Project Structure

```text
automated-linux-update/
├── bin/
│   └── auto-update.sh
├── config/
│   └── update.conf
├── lib/
│   ├── checks.sh
│   ├── error-handler.sh
│   ├── health-monitor.sh
│   ├── logging.sh
│   ├── report-generator.sh
│   └── update-manager.sh
├── systemd/
│   ├── auto-update.service
│   └── auto-update.timer
├── tests/
│   ├── test-update.sh
│   └── test-health.sh
├── logs/
├── reports/
├── dashboard/
├── README.md
└── LICENSE
```

The dashboard is a planned extension and has not yet been implemented.

## 5. Requirements

- Ubuntu Linux
- Bash
- APT
- systemd
- flock
- Standard Linux utilities

## 6. Running the Application

From the project directory:

```bash
./bin/auto-update.sh --help
./bin/auto-update.sh --check
sudo ./bin/auto-update.sh --dry-run
```

The check mode simulates upgrades using existing package lists. Dry-run mode refreshes package lists and simulates upgrades without installing package upgrades.

The real update mode is:

```bash
sudo ./bin/auto-update.sh --update
```

Review the output and repository health before running real upgrades.

## 7. Running Tests

```bash
./tests/test-update.sh
./tests/test-health.sh
```

The tests check Bash syntax, command-line behavior, disk usage checks, and health report generation.

## 8. Systemd Integration

The existing service is installed at:

```text
/etc/systemd/system/auto-update.service
```

The timer is installed at:

```text
/etc/systemd/system/auto-update.timer
```

Check the timer:

```bash
systemctl status auto-update.timer --no-pager
systemctl list-timers --all auto-update.timer
```

View service logs:

```bash
sudo journalctl -u auto-update.service -n 50 --no-pager
```

The project copies in the `systemd/` directory are not automatically installed system services.

## 9. Safety

- Test in an Ubuntu virtual machine.
- Run the dry-run mode before real upgrades.
- Never bypass APT signature verification.
- Do not automatically reboot the machine.
- Keep backups before replacing the existing production script.
- Validate the new application before connecting it to the live systemd service.

## 10. Future Enhancements

- Improved APT repository failure detection
- Configurable disk and memory thresholds
- Email notifications
- Historical reports and log rotation
- Automated failure and recovery tests
- Python and Flask monitoring dashboard
- Optional monitoring of multiple Linux machines

## 11. Project Status

The modular Bash application and initial tests have been created. Integration testing, stronger failure detection, deployment, and dashboard development remain in progress.
