
from pathlib import Path
from datetime import datetime
import re
import subprocess

from flask import Flask, render_template_string

ROOT = Path(__file__).resolve().parent.parent
LOG_FILE = ROOT / "logs" / "auto-update.log"
REPORT_DIR = ROOT / "reports"

app = Flask(__name__)

HTML = """
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="refresh" content="30">
<title>Linux Update Center</title>
<style>
:root {
    --bg: #0b1120;
    --panel: #131c2e;
    --panel2: #18243a;
    --border: #26344b;
    --text: #e8eef8;
    --muted: #91a0b8;
    --blue: #60a5fa;
    --green: #34d399;
    --yellow: #fbbf24;
    --red: #fb7185;
}
* { box-sizing: border-box; }
body {
    margin: 0;
    background: var(--bg);
    color: var(--text);
    font-family: Inter, system-ui, Arial, sans-serif;
}
header {
    padding: 26px clamp(18px, 5vw, 64px);
    border-bottom: 1px solid var(--border);
    background: #0e1728;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 16px;
    flex-wrap: wrap;
}
.brand { display: flex; align-items: center; gap: 13px; }
.logo {
    width: 45px; height: 45px; border-radius: 13px;
    display: grid; place-items: center;
    color: var(--blue); background: #1b3150;
    font-size: 22px; font-weight: 800;
}
h1 { font-size: 22px; margin: 0; }
.subtitle { color: var(--muted); font-size: 13px; margin-top: 5px; }
main { max-width: 1440px; margin: auto; padding: 28px clamp(18px, 5vw, 64px); }
.section-title {
    font-size: 15px; color: var(--muted);
    margin: 28px 0 14px; font-weight: 650;
    text-transform: uppercase; letter-spacing: 1px;
}
.grid {
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: 16px;
}
.card {
    background: var(--panel);
    border: 1px solid var(--border);
    border-radius: 15px;
    padding: 20px;
    min-width: 0;
}
.metric-label { color: var(--muted); font-size: 13px; }
.metric-value { font-size: 27px; font-weight: 750; margin: 12px 0 8px; }
.metric-note { color: var(--muted); font-size: 12px; overflow-wrap: anywhere; }
.track {
    height: 6px; background: #27344a; border-radius: 9px;
    margin: 13px 0 10px; overflow: hidden;
}
.fill { height: 100%; background: var(--blue); border-radius: 9px; }
.fill.warn { background: var(--yellow); }
.fill.danger { background: var(--red); }
.status {
    display: inline-flex; align-items: center; gap: 7px;
    border-radius: 20px; padding: 7px 11px;
    font-size: 12px; font-weight: 700;
    background: #12382f; color: var(--green);
}
.status.warn { background: #43351b; color: var(--yellow); }
.status.bad { background: #451f2a; color: var(--red); }
.dot { width: 7px; height: 7px; border-radius: 50%; background: currentColor; }
.two-col {
    display: grid; grid-template-columns: 1.2fr 0.8fr; gap: 16px;
}
h2 { font-size: 16px; margin: 0 0 18px; }
.row {
    display: flex; align-items: center; justify-content: space-between;
    gap: 12px; padding: 12px 0; border-bottom: 1px solid var(--border);
}
.row:last-child { border-bottom: 0; }
.label { color: var(--muted); font-size: 13px; }
.value { font-size: 13px; text-align: right; overflow-wrap: anywhere; }
pre {
    white-space: pre-wrap; overflow-wrap: anywhere;
    max-height: 330px; overflow: auto; margin: 0;
    color: #b8c8df; font-size: 12px; line-height: 1.8;
}
table { width: 100%; border-collapse: collapse; font-size: 13px; }
th, td { text-align: left; padding: 13px 8px; border-bottom: 1px solid var(--border); }
th { color: var(--muted); font-weight: 600; }
td { overflow-wrap: anywhere; }
a { color: var(--blue); text-decoration: none; }
a:hover { text-decoration: underline; }
footer { color: var(--muted); font-size: 12px; padding: 28px 0 10px; }
@media (max-width: 900px) {
    .grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
    .two-col { grid-template-columns: 1fr; }
}
@media (max-width: 480px) {
    .grid { grid-template-columns: 1fr; }
    .metric-value { font-size: 24px; }
    header { align-items: flex-start; }
}
</style>
</head>
<body>
<header>
    <div class="brand">
        <div class="logo">LX</div>
        <div>
            <h1>Linux Update Center</h1>
            <div class="subtitle">Automated system monitoring and update reports</div>
        </div>
    </div>
    <div>
        <span class="status {{ service_class }}">
            <span class="dot"></span>{{ service }}
        </span>
    </div>
</header>

<main>
    <div class="section-title">System overview</div>
    <div class="grid">
        <section class="card">
            <div class="metric-label">Root disk usage</div>
            <div class="metric-value">{{ disk_percent }}</div>
            <div class="track"><div class="fill {{ disk_class }}"
                style="width:{{ disk_percent_num }}%"></div></div>
            <div class="metric-note">{{ disk_detail }}</div>
        </section>
        <section class="card">
            <div class="metric-label">Memory usage</div>
            <div class="metric-value">{{ memory_percent }}</div>
            <div class="track"><div class="fill {{ memory_class }}"
                style="width:{{ memory_percent_num }}%"></div></div>
            <div class="metric-note">{{ memory_detail }}</div>
        </section>
        <section class="card">
            <div class="metric-label">Hostname</div>
            <div class="metric-value">{{ hostname }}</div>
            <div class="metric-note">Linux host identity</div>
        </section>
        <section class="card">
            <div class="metric-label">Generated reports</div>
            <div class="metric-value">{{ reports|length }}</div>
            <div class="metric-note">Health reports available</div>
        </section>
    </div>

    <div class="section-title">Monitoring and activity</div>
    <div class="two-col">
        <section class="card">
            <h2>System information</h2>
            <div class="row"><span class="label">Uptime</span>
                <span class="value">{{ uptime }}</span></div>
            <div class="row"><span class="label">Timer state</span>
                <span class="value">{{ service }}</span></div>
            <div class="row"><span class="label">Last report</span>
                <span class="value">{{ latest_report or "No reports yet" }}</span></div>
            <div class="row"><span class="label">Dashboard refreshed</span>
                <span class="value">{{ now }}</span></div>
        </section>
        <section class="card">
            <h2>Recent application logs</h2>
            <pre>{{ logs }}</pre>
        </section>
    </div>

    <div class="section-title">Health reports</div>
    <section class="card">
        {% if reports %}
        <table>
            <thead><tr><th>Report filename</th><th>Last modified</th></tr></thead>
            <tbody>
            {% for report in reports %}
            <tr>
                <td>{{ report.name }}</td>
                <td>{{ report.modified }}</td>
            </tr>
            {% endfor %}
            </tbody>
        </table>
        {% else %}
        <div class="label">No health reports found yet.</div>
        {% endif %}
    </section>
    <footer>
        Read-only monitoring dashboard · Auto-refreshes every 30 seconds
    </footer>
</main>
</body>
</html>
"""


def run(command, fallback="Unavailable"):
    try:
        result = subprocess.run(
            command, capture_output=True, text=True,
            timeout=5, check=True
        )
        return result.stdout.strip() or fallback
    except (OSError, subprocess.SubprocessError):
        return fallback


def percent_class(value):
    if value >= 90:
        return "danger"
    if value >= 80:
        return "warn"
    return ""


@app.route("/")
def index():
    hostname = run(["hostname"])

    disk_output = run(["df", "-P", "/"], "")
    disk_percent_num = 0
    disk_detail = "Disk information unavailable"
    match = re.search(r"\n\S+\s+\S+\s+\S+\s+\S+\s+(\d+)%\s+(.+)", disk_output)
    if match:
        disk_percent_num = min(100, int(match.group(1)))
        disk_detail = f"Mounted on {match.group(2)}"

    memory_output = run(["free", "-m"], "")
    memory_percent_num = 0
    memory_detail = "Memory information unavailable"
    match = re.search(r"^Mem:\s+(\d+)\s+(\d+)", memory_output, re.M)
    if match and int(match.group(1)) > 0:
        total, used = int(match.group(1)), int(match.group(2))
        memory_percent_num = min(100, round(used * 100 / total))
        memory_detail = f"{used} MB used of {total} MB"

    service_raw = run(
        ["systemctl", "is-active", "auto-update.timer"], "unknown"
    )
    service = service_raw.upper()
    service_class = "" if service_raw == "active" else "warn"

    logs = "No log file found."
    if LOG_FILE.is_file():
        logs = "\n".join(
            LOG_FILE.read_text(errors="replace").splitlines()[-35:]
        )

    report_paths = sorted(
        REPORT_DIR.glob("health-report-*.txt"),
        key=lambda p: p.stat().st_mtime,
        reverse=True
    ) if REPORT_DIR.is_dir() else []

    reports = [
        {
            "name": p.name,
            "modified": datetime.fromtimestamp(
                p.stat().st_mtime
            ).strftime("%Y-%m-%d %H:%M"),
        }
        for p in report_paths
    ]

    uptime = run(["uptime", "-p"])
    return render_template_string(
        HTML,
        hostname=hostname,
        disk_percent=f"{disk_percent_num}%",
        disk_percent_num=disk_percent_num,
        disk_detail=disk_detail,
        disk_class=percent_class(disk_percent_num),
        memory_percent=f"{memory_percent_num}%",
        memory_percent_num=memory_percent_num,
        memory_detail=memory_detail,
        memory_class=percent_class(memory_percent_num),
        service=service,
        service_class=service_class,
        logs=logs,
        reports=reports,
        latest_report=reports[0]["name"] if reports else None,
        uptime=uptime,
        now=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    )


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
