STM32L452RE SENSOR MONITOR (HAL + FreeRTOS)
==========================================

Added application files:
  Core/Inc/sensor_app.h
  Core/Src/sensor_app.c

Updated:
  Core/Src/freertos.c - starts the sensor application in the default FreeRTOS task
  Core/Inc/FreeRTOSConfig.h - larger heap for sensor task/stack

PIN CONNECTIONS (match the current CubeMX .ioc configuration)
-------------------------------------------------------------
DHT11:
  VCC  -> 3.3V (check your sensor module's allowed supply)
  GND  -> GND
  DATA -> PA1
  Add a 4.7k-10k pull-up resistor between DATA and 3.3V if your module does not include one.

PIR module:
  VCC -> supply allowed by the specific PIR module (many modules use 5V; check its datasheet)
  GND -> STM32 GND
  OUT -> PA0
  Make sure the OUT voltage never exceeds the STM32 GPIO input limit (3.3V logic).

LED:
  Uses the board's PA5 output. On a Nucleo-L452RE, PA5 is commonly connected to the user LED.
  The LED turns on while PIR output is HIGH.

SSD1306 I2C OLED:
  VCC -> supply allowed by the OLED module; 3.3V is preferred
  GND -> GND
  SCL -> PA9 (I2C1_SCL in this project)
  SDA -> PA10 (I2C1_SDA in this project)
  The driver assumes I2C address 0x3C. Some displays use 0x3D; change OLED_ADDR in sensor_app.c if needed.
  Use an SSD1306-compatible 128x64 display. Other controller/chip variants may need different initialization.

UART / MINICOM
--------------
USART2 TX=PA2, RX=PA3, 115200 baud, 8-N-1. On the Nucleo ST-LINK virtual COM port,
Minicom usually appears as /dev/ttyACM0 (verify with: ls -l /dev/ttyACM*).
Open with: sudo minicom -D /dev/ttyACM0 -b 115200

WHAT IT DOES
------------
1. Starts the FreeRTOS default task.
2. Initializes cycle counter timing for DHT11 microsecond pulses.
3. Initializes the SSD1306 OLED and sends startup text to UART.
4. Every two seconds reads DHT11 temperature/humidity, reads PIR output, controls PA5 LED,
   prints results/errors to UART, and refreshes the OLED if initialization succeeded.

IMPORTANT
---------
This source is provided as an integration starting point and has not been compiled or tested on
physical hardware in this environment. Build in STM32CubeIDE and address any compiler errors first.
If the project was regenerated from the .ioc, reapply the custom files/changes or avoid regenerating
without backing them up. Do not run the old bare-metal main() alongside this HAL/FreeRTOS application.
