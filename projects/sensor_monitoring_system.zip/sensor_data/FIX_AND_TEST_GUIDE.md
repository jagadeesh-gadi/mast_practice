# FreeRTOS sensor tasks: build and test

## Tasks created
- `DHT11Task`: reads DHT11 on PA1 every 2 seconds.
- `PIRTask`: reads PIR on PA0 every 100 ms and drives LED PA5; reports only initial state and changes.
- `DisplayTask`: receives events from an RTOS message queue and updates Minicom and SSD1306 OLED. It is the sole owner of UART and I2C display output.

## Build/run
1. Back up the original project.
2. Extract the ZIP and import `main_project_sensor_ready/sensor_data` in STM32CubeIDE using **File > Import > Existing Projects into Workspace**.
3. Clean and build the project.
4. Flash the STM32L452RE NUCLEO board.
5. Open Minicom on `/dev/ttyACM0` at 115200 baud, 8 data bits, no parity, 1 stop bit, no flow control.

## Wiring checks
- DHT11 VCC to 3.3 V, GND to GND, DATA to PA1. Bare DHT11 sensors normally require a 4.7 kOhm to 10 kOhm pull-up from DATA to 3.3 V; some modules already have it. Never pull DATA up to 5 V.
- PIR output to PA0, VCC/GND according to the module specification.
- LED output uses PA5.
- SSD1306 I2C uses PA9 (SCL), PA10 (SDA), address 0x3C in this source.

## Important
The ZIP contains source changes, but this environment did not run a fresh STM32CubeIDE build or test the physical board. Confirm a successful build and inspect Minicom output. DHT11 errors can still occur due to wiring, pull-up, timing, sensor/module, or clock configuration.

## USART2 TX DMA
- UART output uses DMA1 Channel 7 through `HAL_UART_Transmit_DMA()` and a persistent 8-message transmit queue.
- See `DMA_IMPLEMENTATION.md` for changed files and test steps.
- The CubeMX `.ioc` has not been regenerated; do not regenerate code from it until DMA is enabled in the CubeMX GUI as well.
