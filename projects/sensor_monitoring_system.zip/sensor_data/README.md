

## FreeRTOS multitasking update

The application uses three CMSIS-RTOS v2 tasks: `DHT11Task` reads the DHT11 every 2 seconds, `PIRTask` samples the PIR every 100 ms and controls the LED, and `DisplayTask` is the only task that writes to UART/OLED. A message queue transfers sensor events to the display task to avoid concurrent UART/I2C access. See `FIX_AND_TEST_GUIDE.md` for build and hardware checks.
