# USART2 TX DMA + DHT11 threshold / DANGER OLED behavior

## Required behavior
- Default thresholds: temperature > 30 C and relative humidity > 70%.
- When either threshold is exceeded, the OLED status line shows `DANGER: TEMP HIGH`, `DANGER: HUM HIGH`, or `DANGER: BOTH HIGH`.
- The firmware sends a UART DANGER alert through the existing USART2 TX DMA queue.
- Threshold-exceeded sensor values are NOT sent as CSV sensor values.
- Motion CSV rows are sent only when motion is detected, the latest DHT11 sample is valid, and both values are within thresholds.
- When readings return within both thresholds, the OLED shows `STATUS: NORMAL`, and normal motion readings can again be recorded.
- Linux logger records only `CSV,MOTION,...` messages in `motion_log.csv`. It does not save DANGER alert messages or threshold-exceeded readings.

## Threshold settings
Edit in `Core/Src/sensor_app.c`:
```c
#define TEMP_MAX_C              30U
#define HUMIDITY_MAX_PERCENT    70U
```

## Pins retained
- DHT11: PA1
- PIR: PA0
- LED: PA5
- USART2 TX/RX: PA2/PA3, 115200 baud, 8-N-1
- OLED I2C1 SCL/SDA: PA9/PA10, address 0x3C

## Build and test
1. Import the project into STM32CubeIDE.
2. Clean and build the project.
3. Flash the NUCLEO-L452RE.
4. Verify OLED danger/normal status and serial messages.
5. Build Linux logger: `gcc -Wall -Wextra motion_logger.c -o motion_logger`.
6. Run one serial reader at a time on the actual serial port.

## Validation limitation
Source changes are packaged, but a fresh STM32 cross-compilation and physical board test were not run here. Verify the full build and behavior on STM32CubeIDE and the target hardware. Do not regenerate from `.ioc` until USART2 TX DMA is configured there, or generated code may overwrite manual DMA changes.
