#ifndef SENSOR_APP_H
#define SENSOR_APP_H

#include "main.h"
#include <stdint.h>

typedef enum {
    SENSOR_EVENT_DHT = 1,
    SENSOR_EVENT_PIR = 2
} SensorEventType_t;

typedef struct {
    SensorEventType_t type;
    uint8_t humidity;
    uint8_t temperature;
    int dht_status;
    GPIO_PinState pir_state;
} SensorEvent_t;

void SensorApp_Init(void);
int SensorApp_ReadDHT(uint8_t *humidity, uint8_t *temperature);
GPIO_PinState SensorApp_ReadPIRAndSetLED(void);
void SensorApp_Report(const SensorEvent_t *event,
                      uint8_t *humidity, uint8_t *temperature, int *dht_status,
                      GPIO_PinState *pir_state, uint8_t *have_dht, uint8_t *have_pir);

#endif /* SENSOR_APP_H */
