#include "dma.h"

/* STM32L452RE uses fixed DMA request selection (no DMAMUX1).
 * USART2_TX is configured as DMA_REQUEST_2 on DMA1 Channel 7 in usart.c. */
void MX_DMA_Init(void)
{
    __HAL_RCC_DMA1_CLK_ENABLE();

    /* This IRQ only advances the UART DMA queue; it does not call FreeRTOS APIs. */
    HAL_NVIC_SetPriority(DMA1_Channel7_IRQn, 5U, 0U);
    HAL_NVIC_EnableIRQ(DMA1_Channel7_IRQn);
}
