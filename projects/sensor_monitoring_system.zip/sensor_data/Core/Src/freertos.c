/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * File Name          : freertos.c
  * Description        : Separate FreeRTOS tasks for DHT11 and PIR sensors.
  ******************************************************************************
  */
/* USER CODE END Header */

#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"
#include "sensor_app.h"

/* Queue transports sensor results to one display/output task. */
static osMessageQueueId_t sensorQueueHandle;
static osThreadId_t dhtTaskHandle;
static osThreadId_t pirTaskHandle;
static osThreadId_t displayTaskHandle;

static const osThreadAttr_t dhtTask_attributes = {
    .name = "DHT11Task",
    .stack_size = 1024,
    .priority = osPriorityNormal
};
static const osThreadAttr_t pirTask_attributes = {
    .name = "PIRTask",
    .stack_size = 512,
    .priority = osPriorityAboveNormal
};
static const osThreadAttr_t displayTask_attributes = {
    .name = "DisplayTask",
    .stack_size = 2048,
    .priority = osPriorityBelowNormal
};

static void StartDHT11Task(void *argument);
static void StartPIRTask(void *argument);
static void StartDisplayTask(void *argument);

void MX_FREERTOS_Init(void)
{
    /* Initialize DWT, UART and OLED before sensor tasks start. */
    SensorApp_Init();

    sensorQueueHandle = osMessageQueueNew(8U, sizeof(SensorEvent_t), NULL);
    if (sensorQueueHandle == NULL) Error_Handler();

    dhtTaskHandle = osThreadNew(StartDHT11Task, NULL, &dhtTask_attributes);
    pirTaskHandle = osThreadNew(StartPIRTask, NULL, &pirTask_attributes);
    displayTaskHandle = osThreadNew(StartDisplayTask, NULL, &displayTask_attributes);

    if (dhtTaskHandle == NULL || pirTaskHandle == NULL || displayTaskHandle == NULL)
        Error_Handler();
}

/* Task 1: DHT11 is sampled every 2 seconds. */
static void StartDHT11Task(void *argument)
{
    (void)argument;
    SensorEvent_t event = {0};
    event.type = SENSOR_EVENT_DHT;

    for (;;) {
        event.dht_status = SensorApp_ReadDHT(&event.humidity, &event.temperature);
        (void)osMessageQueuePut(sensorQueueHandle, &event, 0U, 100U);
        osDelay(2000U);
    }
}

/* Task 2: PIR is polled every 100 ms; report only initial/state changes. */
static void StartPIRTask(void *argument)
{
    (void)argument;
    SensorEvent_t event = {0};
    GPIO_PinState previous = GPIO_PIN_RESET;
    uint8_t first = 1U;

    for (;;) {
        GPIO_PinState current = SensorApp_ReadPIRAndSetLED();
        if (first || current != previous) {
            event.type = SENSOR_EVENT_PIR;
            event.pir_state = current;
            (void)osMessageQueuePut(sensorQueueHandle, &event, 0U, 100U);
            previous = current;
            first = 0U;
        }
        osDelay(100U);
    }
}

/* Task 3: Sole owner of UART/OLED output; consumes sensor events from queue. */
static void StartDisplayTask(void *argument)
{
    (void)argument;
    SensorEvent_t event;
    uint8_t humidity = 0U, temperature = 0U;
    int dht_status = -99;
    GPIO_PinState pir_state = GPIO_PIN_RESET;
    uint8_t have_dht = 0U, have_pir = 0U;

    for (;;) {
        if (osMessageQueueGet(sensorQueueHandle, &event, NULL, osWaitForever) == osOK) {
            SensorApp_Report(&event, &humidity, &temperature, &dht_status,
                             &pir_state, &have_dht, &have_pir);
        }
    }
}
