
#define _DEFAULT_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <termios.h>
#include <time.h>

#define SERIAL_PORT "/dev/ttyACM0"
#define CSV_FILE "motion_log.csv"

int main(void)
{
    int serial_fd;
    FILE *csv_file;
    struct termios options;

    char ch;
    char line[256];
    int index = 0;

    int temperature;
    int humidity;

    /* Open STM32 UART serial port */
    serial_fd = open(SERIAL_PORT, O_RDONLY | O_NOCTTY);

    if (serial_fd < 0)
    {
        perror("Unable to open serial port");
        return 1;
    }

    /* Get serial port configuration */
    if (tcgetattr(serial_fd, &options) != 0)
    {
        perror("tcgetattr failed");
        close(serial_fd);
        return 1;
    }

    /* Configure UART: 115200 baud, 8 data bits, no parity, 1 stop bit */
    cfmakeraw(&options);

    cfsetispeed(&options, B115200);
    cfsetospeed(&options, B115200);

    options.c_cflag |= CLOCAL | CREAD;
    options.c_cflag &= ~CSTOPB;
    options.c_cflag &= ~PARENB;
    options.c_cflag &= ~CSIZE;
    options.c_cflag |= CS8;

    options.c_cc[VMIN] = 1;
    options.c_cc[VTIME] = 0;

    if (tcsetattr(serial_fd, TCSANOW, &options) != 0)
    {
        perror("tcsetattr failed");
        close(serial_fd);
        return 1;
    }

    /* Open CSV file in append mode */
    csv_file = fopen(CSV_FILE, "a");

    if (csv_file == NULL)
    {
        perror("Unable to open CSV file");
        close(serial_fd);
        return 1;
    }

    /* Write CSV header only if the file is empty */
    fseek(csv_file, 0, SEEK_END);

    if (ftell(csv_file) == 0)
    {
        fprintf(csv_file,
                "Timestamp,Event,Temperature_C,Humidity_Percent\n");

        fflush(csv_file);
    }

    printf("Motion CSV logger started.\n");
    printf("CSV file: %s\n", CSV_FILE);
    printf("Waiting for motion events...\n");

    /* Receive UART messages continuously */
    while (1)
    {
        ssize_t bytes = read(serial_fd, &ch, 1);

        if (bytes <= 0)
        {
            continue;
        }

        if (ch == '\r')
        {
            continue;
        }

        if (ch == '\n')
        {
            line[index] = '\0';

            /*
             * Expected STM32 message:
             * CSV,MOTION,29,65
             */

            if (sscanf(line, "CSV,MOTION,%d,%d",
                       &temperature, &humidity) == 2)
            {
                time_t now = time(NULL);
                struct tm *local_time = localtime(&now);
                char timestamp[32];

                if (local_time != NULL)
                {
                    strftime(timestamp,
                             sizeof(timestamp),
                             "%Y-%m-%d %H:%M:%S",
                             local_time);

                    fprintf(csv_file,
                            "%s,MOTION,%d,%d\n",
                            timestamp,
                            temperature,
                            humidity);
                    fflush(csv_file);

                    printf("Logged: %s,MOTION,%d,%d\n",
                           timestamp,
                           temperature,
                           humidity);
                }
            }

            index = 0;
        }
        else if (index < (int)sizeof(line) - 1)
        {
            line[index++] = ch;
        }
        else
        {
            /* Reset if the received line is too long */
            index = 0;
        }
    }

    fclose(csv_file);
    close(serial_fd);

    return 0;
}

