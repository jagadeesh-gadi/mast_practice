# STM32L452RE PIR/DHT11 motion CSV logger

## What this project does
- FreeRTOS DHT11 task samples temperature and humidity.
- FreeRTOS PIR task continuously checks motion and controls the LED.
- The display task updates the OLED.
- On a PIR LOW-to-HIGH transition, STM32 sends exactly one line using USART2 TX DMA:
  `EVENT,<temperature_c>,<humidity_percent>,MOTION_DETECTED`
- The Ubuntu C program receives that line and appends a timestamped row to `motion_log.csv`.
- The timestamp is the Ubuntu PC's local time when the event is received.

## Hardware/pin map
- DHT11 DATA: PA1; VCC 3.3 V; GND to GND.
- PIR OUT: PA0; VCC/GND according to the PIR module; output must be safe for 3.3 V GPIO.
- LED: PA5.
- USART2 TX/RX: PA2/PA3 through the Nucleo ST-LINK virtual COM port.
- SSD1306 I2C: PA9 SCL, PA10 SDA, address 0x3C (if the OLED is connected).

For a bare DHT11, use a 4.7k-10k pull-up from DATA to 3.3 V. Some breakout modules already include a pull-up. Never pull DATA up to 5 V.

## Build and flash
1. Import `sensor_data` into STM32CubeIDE.
2. Run **Project > Clean**, then **Build Project**.
3. Flash the STM32L452RE board.
4. Verify the project builds without errors. A successful host logger build does not prove the physical DMA hardware works; test with the connected board.

## Run the Ubuntu CSV logger
Close Minicom and any other program using `/dev/ttyACM0`. Only one process can read this serial port reliably at a time.

From a terminal:
```bash
cd ~/Downloads/main_project_using_DMA/main_project_DMA/sensor_data
./pc_logger/run_logger.sh
```
If the project is extracted elsewhere, change the `cd` path to that extracted `sensor_data` directory.

The script compiles `pc_logger/motion_logger.c` and runs it. `motion_log.csv` is created in the `sensor_data` directory. Keep the logger running, wait until the DHT11 has produced a valid reading, then let the PIR output return LOW and trigger motion so the PIR produces a new rising edge.

To inspect the CSV from another terminal:
```bash
cat ~/Downloads/main_project_using_DMA/main_project_DMA/sensor_data/motion_log.csv
```
Use the actual extracted project path if it differs.

## Expected serial/log output
PC terminal:
```text
RX: EVENT,23,22,MOTION_DETECTED
Logged motion at 2026-10-24 13:20:10 (T=23 C, RH=22%)
```

CSV:
```csv
timestamp,temperature_c,humidity_percent,motion
2026-10-24 13:20:10,23,22,MOTION_DETECTED
```

Only valid `EVENT,...,MOTION_DETECTED` lines are logged. Normal display text is intentionally not sent over UART so it cannot mix with DMA event records. The OLED continues to show the sensor status.

## Troubleshooting
- `Cannot open serial port`: close Minicom; check `ls -l /dev/ttyACM0`. If permission denied, add your user to `dialout`, then log out/in:
  `sudo usermod -aG dialout "$USER"`
- `RX:` shows no messages: verify USB connection, flash the updated firmware, and check the DMA IRQ/channel configuration.
- `RX: EVENT,-1,-1,MOTION_DETECTED`: the PIR event reached the PC, but the DHT11 has not returned a successful sample yet. Check PA1 wiring, common ground, 3.3 V, and pull-up.
- DHT11 error `-11` means the MCU did not observe the sensor's response LOW pulse. Check wiring and sensor power; wait a few seconds after power-up.
- One row is written per PIR LOW-to-HIGH transition. If PIR stays HIGH, wait for it to return LOW before testing another motion event.
- Timestamp is PC receipt time, not an STM32 RTC timestamp.


## Important recovery steps for corrupted UART output

1. Close Minicom before running the PC logger. Only one program should read `/dev/ttyACM0` at a time.
2. Re-import or refresh the `sensor_data` project from this ZIP, then use **Project > Clean** and **Build Project**.
3. Flash the newly built firmware to the board. Rebuilding without flashing leaves the previous firmware running.
4. Start `pc_logger/run_logger.sh` before triggering motion.
5. USART2 is intentionally reserved for structured `EVENT,...` and `STATE,NO_MOTION` records. Human-readable sensor status belongs on the OLED, not UART.
6. The PIR software polling interval is 20 ms. The PIR module itself may hold its output high for several seconds depending on its hardware time-delay setting.

Motion-session logging behavior: the C logger starts a session on MOTION DETECTED, keeps it open while motion is active, and writes exactly one CSV row when NO MOTION is received. The row contains start timestamp, end timestamp, elapsed seconds, temperature, humidity, and MOTION_ENDED. If the logger is stopped before NO MOTION arrives, the active session is reported as not finalized.
