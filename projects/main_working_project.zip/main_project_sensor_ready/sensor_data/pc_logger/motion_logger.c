#define _DEFAULT_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <termios.h>
#include <time.h>
#include <unistd.h>
#include <sys/stat.h>

#define LOG_FILE "motion_log.csv"
#define HEADER "timestamp,temperature_c,humidity_percent,motion_status,event\n"
static volatile sig_atomic_t stop_requested = 0;
static void on_signal(int sig) { (void)sig; stop_requested = 1; }

static const char *choose_port(void) {
    const char *env = getenv("SERIAL_PORT");
    if (env && *env) return env;
    if (access("/dev/ttyACM1", R_OK | W_OK) == 0) return "/dev/ttyACM1";
    if (access("/dev/ttyACM0", R_OK | W_OK) == 0) return "/dev/ttyACM0";
    if (access("/dev/ttyUSB0", R_OK | W_OK) == 0) return "/dev/ttyUSB0";
    return NULL;
}
static int configure_serial(int fd) {
    struct termios tty;
    if (tcgetattr(fd, &tty) != 0) return -1;
    cfmakeraw(&tty);
    if (cfsetispeed(&tty, B115200) != 0 || cfsetospeed(&tty, B115200) != 0) return -1;
    tty.c_cflag |= CLOCAL | CREAD;
    tty.c_cflag &= ~(CSTOPB | PARENB | CSIZE);
    tty.c_cflag |= CS8;
#ifdef CRTSCTS
    tty.c_cflag &= ~CRTSCTS;
#endif
    tty.c_cc[VMIN] = 0; tty.c_cc[VTIME] = 1;
    return tcsetattr(fd, TCSANOW, &tty);
}
static void timestamp(char *out, size_t cap) {
    time_t now = time(NULL); struct tm t;
    if (!localtime_r(&now, &t) || !strftime(out, cap, "%Y-%m-%d %H:%M:%S", &t))
        snprintf(out, cap, "TIME_ERROR");
}
static FILE *open_csv(void) {
    FILE *f = fopen(LOG_FILE, "a+"); if (!f) return NULL;
    struct stat st;
    if (fstat(fileno(f), &st) == 0 && st.st_size == 0) {
        if (fputs(HEADER, f) < 0 || fflush(f) != 0) { fclose(f); return NULL; }
    }
    return f;
}
static void save_row(FILE *csv, const char *temp, const char *hum, const char *status, const char *event) {
    char ts[32]; timestamp(ts, sizeof ts);
    if (fprintf(csv, "%s,%s,%s,%s,%s\n", ts, temp, hum, status, event) < 0 || fflush(csv) != 0) {
        perror("[CSV ERROR]");
    } else {
        printf("[CSV SAVED] %s | temp=%s C | humidity=%s %% | status=%s | event=%s\n", ts,
               *temp ? temp : "N/A", *hum ? hum : "N/A", status, event);
        fflush(stdout);
    }
}
int main(void) {
    signal(SIGINT, on_signal); signal(SIGTERM, on_signal);
    const char *port = choose_port();
    if (!port) { fprintf(stderr, "ERROR: no serial port found. Set SERIAL_PORT=/dev/ttyACM1 if needed.\n"); return EXIT_FAILURE; }
    int serial = open(port, O_RDONLY | O_NOCTTY | O_NONBLOCK);
    if (serial < 0) { perror("ERROR opening serial port (close Minicom first)"); return EXIT_FAILURE; }
    if (configure_serial(serial) != 0) { perror("ERROR configuring serial port"); close(serial); return EXIT_FAILURE; }
    FILE *csv = open_csv();
    if (!csv) { perror("ERROR opening CSV"); close(serial); return EXIT_FAILURE; }
    printf("C-only LIVE motion logger listening on %s at 115200 baud.\n", port);
    printf("A CSV row is saved for every DHT sample while motion is active, plus start/end rows.\nCSV: %s\n", LOG_FILE);
    fflush(stdout);

    int active = 0, last_temp = -1, last_hum = -1;
    char line[512]; size_t used = 0; char ch;
    while (!stop_requested) {
        ssize_t n = read(serial, &ch, 1);
        if (n < 0) { if (errno == EINTR || errno == EAGAIN || errno == EWOULDBLOCK) { usleep(10000); continue; } perror("serial read"); break; }
        if (n == 0) { usleep(10000); continue; }
        if (ch != '\n') { if (used < sizeof line - 1) line[used++] = ch; else used = 0; continue; }
        line[used] = '\0'; if (used && line[used-1] == '\r') line[used-1] = '\0';
        if (!used) continue;
        printf("[UART RX] %s\n", line); fflush(stdout);
        if (strstr(line, "NO MOTION") || strstr(line, "STATE,NO_MOTION")) {
            if (active) {
                char t[12] = "", h[12] = "";
                if (last_temp >= 0) snprintf(t, sizeof t, "%d", last_temp);
                if (last_hum >= 0) snprintf(h, sizeof h, "%d", last_hum);
                save_row(csv, t, h, "NO_MOTION", "SESSION_END");
                active = 0; last_temp = last_hum = -1;
                printf("[MOTION END] session closed.\n"); fflush(stdout);
            } else printf("[INFO] NO MOTION; no active session.\n");
        } else if (strncmp(line, "SAMPLE,", 7) == 0) {
            /* Parse SAMPLE before testing for MOTION_DETECTED: the sample's state field
               itself contains that text and must not be mistaken for a new session. */
            int t = -1, h = -1; char state[32] = "";
            if (sscanf(line, "SAMPLE,%d,%d,%31[^,\r\n]", &t, &h, state) == 3 &&
                strcmp(state, "MOTION_DETECTED") == 0) {
                if (!active) {
                    active = 1;
                    printf("[INFO] SAMPLE opened a motion session (start message was not received).\n");
                }
                last_temp = t; last_hum = h;
                char ts[12], hs[12];
                snprintf(ts, sizeof ts, "%d", t); snprintf(hs, sizeof hs, "%d", h);
                save_row(csv, ts, hs, "MOTION_DETECTED", "LIVE_SAMPLE");
            } else {
                printf("[WARN] invalid SAMPLE record: %s\n", line);
            }
        } else if (strncmp(line, "EVENT,", 6) == 0) {
            int t = -1, h = -1; char state[32] = "";
            if (sscanf(line, "EVENT,%d,%d,%31[^,\r\n]", &t, &h, state) == 3) {
                if (strcmp(state, "MOTION_DETECTED") == 0) {
                    if (!active) {
                        active = 1; last_temp = t; last_hum = h;
                        char ts[12], hs[12]; snprintf(ts, sizeof ts, "%d", t); snprintf(hs, sizeof hs, "%d", h);
                        save_row(csv, ts, hs, "MOTION_DETECTED", "SESSION_START");
                    } else {
                        last_temp = t; last_hum = h;
                        printf("[INFO] motion remains active; no duplicate SESSION_START row.\n");
                    }
                } else if (strcmp(state, "NO_MOTION") == 0 && active) {
                    char ts[12] = "", hs[12] = "";
                    if (last_temp >= 0) snprintf(ts, sizeof ts, "%d", last_temp);
                    if (last_hum >= 0) snprintf(hs, sizeof hs, "%d", last_hum);
                    save_row(csv, ts, hs, "NO_MOTION", "SESSION_END"); active = 0; last_temp = last_hum = -1;
                }
            } else printf("[WARN] invalid EVENT record: %s\n", line);
        } else if (strncmp(line, "MOTION DETECTED", 15) == 0 || strstr(line, "MOTION_DETECTED")) {
            int t = -1, h = -1;
            const char *tp = strstr(line, "Temperature:"); if (tp) (void)sscanf(tp, "Temperature: %d", &t);
            const char *hp = strstr(line, "Humidity:"); if (hp) (void)sscanf(hp, "Humidity: %d", &h);
            if (!active) {
                active = 1;
                if (t >= 0) last_temp = t;
                if (h >= 0) last_hum = h;
                char ts[12] = "", hs[12] = "";
                if (t >= 0) snprintf(ts, sizeof ts, "%d", t);
                if (h >= 0) snprintf(hs, sizeof hs, "%d", h);
                save_row(csv, ts, hs, "MOTION_DETECTED", "SESSION_START");
            } else {
                if (t >= 0) last_temp = t;
                if (h >= 0) last_hum = h;
                printf("[INFO] motion remains active; waiting for SAMPLE records.\n");
            }
        } else {
            printf("[INFO] unrecognized UART line ignored.\n");
        }
        used = 0;
    }
    if (active) printf("[WARNING] Motion still active; live samples already saved, but no SESSION_END row received.\n");
    fclose(csv); close(serial); puts("Logger stopped."); return EXIT_SUCCESS;
}
