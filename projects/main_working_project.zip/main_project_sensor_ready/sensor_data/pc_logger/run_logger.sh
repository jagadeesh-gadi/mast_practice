#!/bin/sh
set -eu
PROJECT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$PROJECT_DIR"

# Select the port automatically, or let user override it with SERIAL_PORT.
if [ -z "${SERIAL_PORT:-}" ]; then
    if [ -e /dev/ttyACM1 ]; then export SERIAL_PORT=/dev/ttyACM1
    elif [ -e /dev/ttyACM0 ]; then export SERIAL_PORT=/dev/ttyACM0
    elif [ -e /dev/ttyUSB0 ]; then export SERIAL_PORT=/dev/ttyUSB0
    fi
fi

# C-only logger: no Python, pip, or openpyxl is used.
gcc -std=c11 -Wall -Wextra -Werror -o motion_logger pc_logger/motion_logger.c
exec ./motion_logger
