# Motion logging troubleshooting

1. Use the newly extracted project, then Clean, Build, and flash it to the STM32.
2. Close Minicom before starting the PC logger. Only one process can read `/dev/ttyACM0` at a time.
3. From this `sensor_data` directory run `./pc_logger/run_logger.sh`.
4. Trigger the PIR sensor. Expected line: `MOTION DETECTED | Temperature: 24 C | Humidity: 55 %` followed by `[SAVED]` messages.
5. If no UART line arrives, check that the logger is using the correct serial port, firmware was flashed, PIR DATA is connected to PA0, and the Nucleo virtual COM port is available.
6. If temperature/humidity are blank in CSV, PIR event arrived before the DHT11 produced a valid reading; check DHT11 wiring to PA1, power, common ground, and pull-up.
7. `motion_log.csv` and `motion_log.xlsx` are saved in this directory. Close LibreOffice while logging and reopen the workbook after motion events.

Minicom can be used to inspect the UART output when the logger is stopped, but it cannot run at the same time as the logger on the same `/dev/ttyACM0` port.
