#include "main.h"
#include "i2c.h"
#include "usart.h"
#include "sensor_app.h"
#include "cmsis_os.h"
#include <stdio.h>
#include <string.h>
#include <stdint.h>

/* STM32L452RE NUCLEO pin mapping */
#define DHT_PORT GPIOA
#define DHT_PIN  GPIO_PIN_1
#define PIR_PORT GPIOA
#define PIR_PIN  GPIO_PIN_0
#define LED_PORT GPIOA
#define LED_PIN  GPIO_PIN_5
#define OLED_ADDR (0x3C << 1) /* HAL expects 8-bit shifted address */

static int oled_ready = 0;

/* Send one event record through USART2 TX DMA. Wait until the transfer ends
   so the caller's buffer remains valid. Called only by DisplayTask. */
static HAL_StatusTypeDef uart_event_dma(const char *s)
{
    uint16_t length = (uint16_t)strlen(s);
    if (length == 0U) return HAL_OK;

    /* Prefer DMA. If DMA cannot start or does not complete, fall back to
       blocking UART transmit so a detected event is not silently discarded. */
    HAL_StatusTypeDef status = HAL_UART_Transmit_DMA(&huart2, (uint8_t *)s, length);
    if (status != HAL_OK) {
        return HAL_UART_Transmit(&huart2, (uint8_t *)s, length, 1000U);
    }

    uint32_t start = HAL_GetTick();
    while (HAL_UART_GetState(&huart2) != HAL_UART_STATE_READY) {
        if ((HAL_GetTick() - start) > 500U) {
            (void)HAL_UART_AbortTransmit(&huart2);
            /* Last-resort fallback; preserves the human-readable event line. */
            return HAL_UART_Transmit(&huart2, (uint8_t *)s, length, 1000U);
        }
        osDelay(1U);
    }
    return HAL_OK;
}

static void delay_us(uint32_t us)
{
    uint32_t ticks_per_us = HAL_RCC_GetHCLKFreq() / 1000000U;
    if (ticks_per_us == 0U) return;
    uint32_t start = DWT->CYCCNT;
    uint32_t ticks = us * ticks_per_us;
    while ((uint32_t)(DWT->CYCCNT - start) < ticks) { }
}

/* Wait for a GPIO state with a DWT-based timeout. */
static uint8_t wait_pin(GPIO_PinState state, uint32_t timeout_us)
{
    uint32_t ticks_per_us = HAL_RCC_GetHCLKFreq() / 1000000U;
    if (ticks_per_us == 0U) return 0U;
    uint32_t start = DWT->CYCCNT;
    uint32_t timeout_ticks = timeout_us * ticks_per_us;
    while (HAL_GPIO_ReadPin(DHT_PORT, DHT_PIN) != state) {
        if ((uint32_t)(DWT->CYCCNT - start) >= timeout_ticks) return 0U;
    }
    return 1U;
}

/* DHT11 return codes: 0 success, -2 checksum, -11/-12/-13 response,
   -20/-21 data-bit transition, -14 clock unavailable. */
static int dht11_read(uint8_t *humidity, uint8_t *temperature)
{
    uint8_t data[5] = {0};
    GPIO_InitTypeDef g = {0};
    uint32_t ticks_per_us = HAL_RCC_GetHCLKFreq() / 1000000U;
    int result = 0;
    uint32_t primask;

    if (ticks_per_us == 0U) return -14;

    /* Host start signal: open-drain low for >=18 ms. */
    g.Pin = DHT_PIN;
    g.Mode = GPIO_MODE_OUTPUT_OD;
    g.Pull = GPIO_PULLUP;
    g.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(DHT_PORT, &g);
    HAL_GPIO_WritePin(DHT_PORT, DHT_PIN, GPIO_PIN_RESET);
    HAL_Delay(20);

    /* Release DATA. External 4.7k-10k pull-up to 3.3V is recommended
       for a bare sensor; many 3-pin modules already include one. */
    HAL_GPIO_WritePin(DHT_PORT, DHT_PIN, GPIO_PIN_SET);
    g.Mode = GPIO_MODE_INPUT;
    g.Pull = GPIO_PULLUP;
    HAL_GPIO_Init(DHT_PORT, &g);
    delay_us(2);

    /* DHT response: LOW, HIGH, then LOW. Keep this short handshake timed. */
    if (!wait_pin(GPIO_PIN_RESET, 200U)) return -11;
    if (!wait_pin(GPIO_PIN_SET,   200U)) return -12;
    if (!wait_pin(GPIO_PIN_RESET, 200U)) return -13;

    /* Interrupts can delay software polling enough to miss 26-70 us pulses.
       Mask interrupts only for the 40-bit capture, then restore prior state. */
    primask = __get_PRIMASK();
    __disable_irq();
    for (int i = 0; i < 40; ++i) {
        if (!wait_pin(GPIO_PIN_SET, 100U)) { result = -20; break; }
        uint32_t start = DWT->CYCCNT;
        if (!wait_pin(GPIO_PIN_RESET, 100U)) { result = -21; break; }
        uint32_t pulse_ticks = (uint32_t)(DWT->CYCCNT - start);
        data[i / 8] <<= 1;
        if (pulse_ticks > 40U * ticks_per_us) data[i / 8] |= 1U;
    }
    if (primask == 0U) __enable_irq();
    if (result != 0) return result;

    if ((uint8_t)(data[0] + data[1] + data[2] + data[3]) != data[4]) return -2;
    *humidity = data[0];
    *temperature = data[2];
    return 0;
}

/* ---------------- SSD1306 OLED over I2C ---------------- */
static HAL_StatusTypeDef oled_cmd(uint8_t command)
{
    uint8_t b[2] = {0x00, command};
    return HAL_I2C_Master_Transmit(&hi2c1, OLED_ADDR, b, 2, 100);
}

static HAL_StatusTypeDef oled_data(const uint8_t *p, uint16_t n)
{
    uint8_t b[17];
    while (n > 0U) {
        uint16_t chunk = (n > 16U) ? 16U : n;
        b[0] = 0x40;
        memcpy(&b[1], p, chunk);
        if (HAL_I2C_Master_Transmit(&hi2c1, OLED_ADDR, b, chunk + 1U, 100) != HAL_OK)
            return HAL_ERROR;
        p += chunk;
        n -= chunk;
    }
    return HAL_OK;
}

static void oled_setpos(uint8_t page, uint8_t col)
{
    (void)oled_cmd((uint8_t)(0xB0U | page));
    (void)oled_cmd((uint8_t)(0x00U | (col & 0x0FU)));
    (void)oled_cmd((uint8_t)(0x10U | (col >> 4)));
}

/* Small 5x7 font for characters used by the status screen. */
static void glyph(char c, uint8_t g[5])
{
#define G(a,b,c1,d,e) do { g[0]=(a); g[1]=(b); g[2]=(c1); g[3]=(d); g[4]=(e); } while (0)
    if (c >= 'a' && c <= 'z') c = (char)(c - 'a' + 'A');
    switch (c) {
    case 'A': G(0x7E,0x11,0x11,0x11,0x7E); break;
    case 'B': G(0x7F,0x49,0x49,0x49,0x36); break;
    case 'C': G(0x3E,0x41,0x41,0x41,0x22); break;
    case 'D': G(0x7F,0x41,0x41,0x22,0x1C); break;
    case 'E': G(0x7F,0x49,0x49,0x49,0x41); break;
    case 'F': G(0x7F,0x09,0x09,0x09,0x01); break;
    case 'G': G(0x3E,0x41,0x49,0x49,0x7A); break;
    case 'H': G(0x7F,0x08,0x08,0x08,0x7F); break;
    case 'I': G(0x00,0x41,0x7F,0x41,0x00); break;
    case 'J': G(0x20,0x40,0x41,0x3F,0x01); break;
    case 'K': G(0x7F,0x08,0x14,0x22,0x41); break;
    case 'L': G(0x7F,0x40,0x40,0x40,0x40); break;
    case 'M': G(0x7F,0x02,0x0C,0x02,0x7F); break;
    case 'N': G(0x7F,0x04,0x08,0x10,0x7F); break;
    case 'O': G(0x3E,0x41,0x41,0x41,0x3E); break;
    case 'P': G(0x7F,0x09,0x09,0x09,0x06); break;
    case 'Q': G(0x3E,0x41,0x51,0x21,0x5E); break;
    case 'R': G(0x7F,0x09,0x19,0x29,0x46); break;
    case 'S': G(0x46,0x49,0x49,0x49,0x31); break;
    case 'T': G(0x01,0x01,0x7F,0x01,0x01); break;
    case 'U': G(0x3F,0x40,0x40,0x40,0x3F); break;
    case 'V': G(0x1F,0x20,0x40,0x20,0x1F); break;
    case 'W': G(0x3F,0x40,0x38,0x40,0x3F); break;
    case 'X': G(0x63,0x14,0x08,0x14,0x63); break;
    case 'Y': G(0x07,0x08,0x70,0x08,0x07); break;
    case 'Z': G(0x61,0x51,0x49,0x45,0x43); break;
    case '0': G(0x3E,0x51,0x49,0x45,0x3E); break;
    case '1': G(0x00,0x42,0x7F,0x40,0x00); break;
    case '2': G(0x42,0x61,0x51,0x49,0x46); break;
    case '3': G(0x21,0x41,0x45,0x4B,0x31); break;
    case '4': G(0x18,0x14,0x12,0x7F,0x10); break;
    case '5': G(0x27,0x45,0x45,0x45,0x39); break;
    case '6': G(0x3C,0x4A,0x49,0x49,0x30); break;
    case '7': G(0x01,0x71,0x09,0x05,0x03); break;
    case '8': G(0x36,0x49,0x49,0x49,0x36); break;
    case '9': G(0x06,0x49,0x49,0x29,0x1E); break;
    case ':': G(0x00,0x36,0x36,0x00,0x00); break;
    case '.': G(0x00,0x60,0x60,0x00,0x00); break;
    case '%': G(0x63,0x13,0x08,0x64,0x63); break;
    case '-': G(0x08,0x08,0x08,0x08,0x08); break;
    case '/': G(0x20,0x10,0x08,0x04,0x02); break;
    case ' ': G(0,0,0,0,0); break;
    default: G(0,0,0,0,0); break;
    }
#undef G
}

static void oled_text(uint8_t page, const char *s)
{
    uint8_t line[128];
    uint16_t n = 0;
    while (*s && n < 120U) {
        uint8_t g[5];
        glyph(*s++, g);
        for (int i = 0; i < 5; ++i) line[n++] = g[i];
        line[n++] = 0;
    }
    while (n < 128U) line[n++] = 0;
    oled_setpos(page, 0);
    (void)oled_data(line, 128);
}

static int oled_init(void)
{
    static const uint8_t init[] = {
        0xAE,0xD5,0x80,0xA8,0x3F,0xD3,0x00,0x40,0x8D,0x14,
        0x20,0x02,0xA1,0xC8,0xDA,0x12,0x81,0x7F,0xD9,0xF1,
        0xDB,0x40,0xA4,0xA6,0xAF
    };
    HAL_Delay(100);
    for (unsigned i = 0; i < sizeof(init); ++i)
        if (oled_cmd(init[i]) != HAL_OK) return 0;
    for (uint8_t p = 0; p < 8; ++p) {
        uint8_t zeros[128] = {0};
        oled_setpos(p, 0);
        if (oled_data(zeros, 128) != HAL_OK) return 0;
    }
    oled_text(0, "STM32 SENSOR");
    oled_text(2, "STARTING");
    return 1;
}

void SensorApp_Init(void)
{
    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
    DWT->CYCCNT = 0;
    DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;

    HAL_GPIO_WritePin(LED_PORT, LED_PIN, GPIO_PIN_RESET);

    /* Emit a boot diagnostic so Minicom/logger can confirm USART2 works.
       This is not a motion event and therefore is not added to the CSV. */
    static const uint8_t boot_message[] = "STM32 LOGGER READY | UART2 115200\r\n";
    (void)HAL_UART_Transmit(&huart2, (uint8_t *)boot_message,
                            (uint16_t)(sizeof(boot_message) - 1U), 1000U);

    /* OLED is independent of the UART event path. */
    oled_ready = oled_init();
}

int SensorApp_ReadDHT(uint8_t *humidity, uint8_t *temperature)
{
    if (humidity == NULL || temperature == NULL) return -99;
    return dht11_read(humidity, temperature);
}

GPIO_PinState SensorApp_ReadPIRAndSetLED(void)
{
    GPIO_PinState state = HAL_GPIO_ReadPin(PIR_PORT, PIR_PIN);
    HAL_GPIO_WritePin(LED_PORT, LED_PIN,
                      (state == GPIO_PIN_SET) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    return state;
}

/*
 * Called only by DisplayTask. The OLED provides human-readable status.
 * USART2 carries machine-readable motion transitions and DHT samples while motion is active.
 * This prevents display text from interleaving with CSV event records.
 */
void SensorApp_Report(const SensorEvent_t *event,
                      uint8_t *humidity, uint8_t *temperature, int *dht_status,
                      GPIO_PinState *pir_state, uint8_t *have_dht, uint8_t *have_pir)
{
    if (event == NULL || humidity == NULL || temperature == NULL ||
        dht_status == NULL || pir_state == NULL || have_dht == NULL || have_pir == NULL) {
        return;
    }

    GPIO_PinState previous_pir = *pir_state;
    uint8_t had_previous_pir = *have_pir;

    if (event->type == SENSOR_EVENT_DHT) {
        /* Keep the most recent successful sample if a later DHT read fails. */
        if (event->dht_status == 0) {
            *humidity = event->humidity;
            *temperature = event->temperature;
            *dht_status = 0;
            *have_dht = 1U;
        } else if (*have_dht == 0U) {
            *dht_status = event->dht_status;
        }
    } else if (event->type == SENSOR_EVENT_PIR) {
        *pir_state = event->pir_state;
        *have_pir = 1U;
    }

    /*
     * IMPORTANT: transmit the state/event BEFORE doing slow OLED I2C updates.
     * USART2 is reserved only for structured lines; never send display text
     * through UART. The single DisplayTask is the only DMA TX owner.
     */
    /* While motion is active, send every successful DHT11 sample to the PC.
       DHT11 is sampled by StartDHT11Task every 2 seconds. */
    if (event->type == SENSOR_EVENT_DHT && event->dht_status == 0 &&
        *have_pir != 0U && *pir_state == GPIO_PIN_SET) {
        char sample[80];
        int n = snprintf(sample, sizeof(sample), "SAMPLE,%u,%u,MOTION_DETECTED\r\n",
                         (unsigned)*temperature, (unsigned)*humidity);
        if (n > 0 && (size_t)n < sizeof(sample)) {
            (void)uart_event_dma(sample);
        }
    }

    if (event->type == SENSOR_EVENT_PIR &&
        (!had_previous_pir || event->pir_state != previous_pir)) {
        char record[80];
        int n;

        if (event->pir_state == GPIO_PIN_SET) {
            int temp_value = (*have_dht != 0U) ? (int)*temperature : -1;
            int hum_value = (*have_dht != 0U) ? (int)*humidity : -1;
            n = snprintf(record, sizeof(record),
                         "MOTION DETECTED | Temperature: %d C | Humidity: %d %%\r\n",
                         temp_value, hum_value);
        } else {
            n = snprintf(record, sizeof(record), "NO MOTION\r\n");
        }

        if (n > 0 && (size_t)n < sizeof(record)) {
            HAL_StatusTypeDef tx_status = uart_event_dma(record);
            if (tx_status != HAL_OK) {
                /* Visible fault indicator on the OLED's motion/status line. */
                static const char tx_error[] = "UART TX ERROR\r\n";
                (void)HAL_UART_Transmit(&huart2, (uint8_t *)tx_error,
                                        (uint16_t)(sizeof(tx_error) - 1U), 1000U);
            }
        }
    }

    /* Human-readable output is on the OLED only, not on USART2. */
    if (oled_ready) {
        char tline[22];
        char hline[22];
        const char *motion = (*pir_state == GPIO_PIN_SET) ? "MOTION" : "NO MOTION";

        oled_text(0, "STM32 SENSOR");

        if (*have_dht != 0U) {
            (void)snprintf(tline, sizeof(tline), "TEMP: %u C",
                           (unsigned)*temperature);
            (void)snprintf(hline, sizeof(hline), "HUM: %u %%",
                           (unsigned)*humidity);
            oled_text(2, tline);
            oled_text(4, hline);
        } else {
            oled_text(2, "DHT WAIT");
            oled_text(4, "NO VALID DATA");
        }

        if (*have_pir != 0U) {
            oled_text(6, motion);
        }
    }
}
