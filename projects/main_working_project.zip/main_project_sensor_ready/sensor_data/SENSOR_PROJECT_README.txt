STM32 DHT11 + PIR + OLED — C-only PC motion logger

PC logging is implemented in C only. No Python is invoked and no Python package is required.

Output file: motion_log.csv
Columns: motion_start_time, motion_end_time, duration_seconds, temperature_c, humidity_percent, motion_status
The CSV is a spreadsheet file format: open motion_log.csv directly in Microsoft Excel or LibreOffice Calc. This C-only version does not create a native .xlsx workbook.

Steps:
1. In STM32CubeIDE, open this project, Project > Clean, Build, then flash the firmware.
2. Close Minicom. Only one program can read the serial port at a time.
3. From this sensor_data folder run ./pc_logger/run_logger.sh
4. The logger auto-selects /dev/ttyACM1, /dev/ttyACM0, or /dev/ttyUSB0. Override with e.g. SERIAL_PORT=/dev/ttyACM1 ./pc_logger/run_logger.sh
5. Trigger PIR. On motion start, check [MOTION START]. When the PIR returns to NO MOTION, check [CSV SAVED]. A row is finalized at the end of the motion period.
6. In a second terminal: cat motion_log.csv
7. Open the CSV in LibreOffice/Excel after logging (or while logging, refresh/reopen it).

If no [UART RX] appears when PIR triggers, the PC cannot save the event because no UART line is reaching it. Test with Minicom at 115200 after stopping the logger, and ensure the flashed firmware transmits motion lines on USART2 TX.

Expected firmware lines: MOTION DETECTED | Temperature: 24 C | Humidity: 55 % at motion start, followed by NO MOTION when the sensor clears.
Alternative accepted line: EVENT,24,55,MOTION_DETECTED
Numbers are examples. Timestamp is PC receipt time, not an MCU hardware timestamp.

Motion-session logging behavior: the C logger starts a session on MOTION DETECTED, keeps it open while motion is active, and writes exactly one CSV row when NO MOTION is received. The row contains start timestamp, end timestamp, elapsed seconds, temperature, humidity, and MOTION_ENDED. If the logger is stopped before NO MOTION arrives, the active session is reported as not finalized.
