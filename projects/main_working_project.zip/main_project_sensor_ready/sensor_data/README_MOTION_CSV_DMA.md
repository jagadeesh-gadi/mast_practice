# C-only STM32 motion event CSV logger

The PC logger is implemented in `pc_logger/motion_logger.c`. The launcher
`pc_logger/run_logger.sh` only compiles that C file with GCC and executes it;
it does not run Python or use Python packages.

The firmware transmits readable motion event lines over USART2 at 115200 baud.
The C logger timestamps each received motion event using the PC's local clock
and appends `timestamp,temperature_c,humidity_percent,motion` to
`motion_log.csv`, flushing the file after each event.

Open `motion_log.csv` directly in LibreOffice Calc or Excel. This project does
not create a native `.xlsx` file because the requested data-saving path is C-only.

Run from this directory with Minicom closed:

```bash
./pc_logger/run_logger.sh
```

If needed, choose a port explicitly:

```bash
SERIAL_PORT=/dev/ttyACM1 ./pc_logger/run_logger.sh
```

Motion-session logging behavior: the C logger starts a session on MOTION DETECTED, keeps it open while motion is active, and writes exactly one CSV row when NO MOTION is received. The row contains start timestamp, end timestamp, elapsed seconds, temperature, humidity, and MOTION_ENDED. If the logger is stopped before NO MOTION arrives, the active session is reported as not finalized.
