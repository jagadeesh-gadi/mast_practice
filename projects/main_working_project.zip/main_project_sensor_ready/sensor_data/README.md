# STM32 Motion Sensor + C-only CSV Logger

This project uses C for the PC-side serial receiver and data saving. There are **no Python source files, no Python runtime dependency, and no openpyxl dependency** in the logging workflow.

## Hardware and UART format

- STM32L452RE Nucleo
- PIR: PA0
- DHT11 DATA: PA1
- LED: PA5
- USART2 TX: PA2, 115200 baud, 8-N-1
- OLED: I2C1

Firmware sends these readable lines over USART2:

- `MOTION DETECTED | Temperature: 24 C | Humidity: 55 %`
- `NO MOTION`

The values are examples. If DHT11 has not produced a successful reading yet, firmware sends `-1` and the CSV cells are left blank. The timestamp is the PC's local time when it receives the motion event.

## Build and flash firmware

1. Open this folder as a project in STM32CubeIDE.
2. Select **Project > Clean**, then **Build Project**.
3. Flash the newly built firmware to the board.

## Run the C logger

1. Close Minicom. Only one application can read the serial port at a time.
2. From this `sensor_data` directory run:

   ```bash
   ./pc_logger/run_logger.sh
   ```

3. The script compiles `pc_logger/motion_logger.c` with GCC and runs that C executable. It does not call Python.
4. Trigger the PIR. The terminal should print `[UART RX]` for received lines and `[CSV SAVED]` when a motion record is written.
5. The file `motion_log.csv` is written in this directory. Open it with LibreOffice Calc or Microsoft Excel.

If the board is enumerated as `/dev/ttyACM1`, the script detects it automatically. You can override the port explicitly:

```bash
SERIAL_PORT=/dev/ttyACM1 ./pc_logger/run_logger.sh
```

If the logger starts but no `[UART RX]` messages appear, check the UART transmission first; CSV saving cannot work until a UART event is received.

## CSV columns

`timestamp,temperature_c,humidity_percent,motion`

Each detected-motion event is appended and flushed to disk. This C-only version creates **CSV**, which Excel and LibreOffice can open directly. It does not create a native `.xlsx` workbook; doing so in C would require adding and maintaining a separate XLSX-writing library.

Motion-session logging behavior: the C logger starts a session on MOTION DETECTED, keeps it open while motion is active, and writes exactly one CSV row when NO MOTION is received. The row contains start timestamp, end timestamp, elapsed seconds, temperature, humidity, and MOTION_ENDED. If the logger is stopped before NO MOTION arrives, the active session is reported as not finalized.
